def findMissingRanges(nums, lower, upper):
    result = []
    n = len(nums)

    for i in range(n):
        if nums[i] > lower:
            result.append(getRange(lower, nums[i] - 1))
        lower = nums[i] + 1

    if lower <= upper:
        result.append(getRange(lower, upper))

    return result


def getRange(lower, upper):
    if lower == upper:
        return str(lower)
    else:
        return str(lower) + "->" + str(upper)
nums = [0, 1, 3, 50, 75]
lower = 0
upper = 99
print(findMissingRanges(nums, lower, upper))
