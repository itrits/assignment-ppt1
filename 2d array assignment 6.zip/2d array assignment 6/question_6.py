from collections import Counter

def findOriginalArray(changed):
    if len(changed) % 2 != 0:
        return []

    original = []
    counts = Counter(changed)

    for num in sorted(changed):
        if counts[num] == 0:
            continue
        counts[num] -= 1
        if counts[num * 2] == 0:
            return []
        counts[num * 2] -= 1
        original.append(num)

    return original
changed = [1, 3, 4, 2, 6, 8]
print(findOriginalArray(changed))

