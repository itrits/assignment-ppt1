def removeElement(nums, val):
    i = 0
    j = 0
    while i < len(nums):
        if nums[i] != val:
            nums[j] = nums[i]
            j += 1
        i += 1
    return j

# Example usage
nums = [3, 2, 2, 3]
val = 3
k = removeElement(nums, val)
print("Output:", k)
print("Modified nums:", nums[:k])
