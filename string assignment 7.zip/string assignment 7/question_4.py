def reverseWords(s):
    words = s.split()

    for i in range(len(words)):
        words[i] = words[i][::-1]

    return ' '.join(words)
s = "Let's take LeetCode contest"
print(reverseWords(s))  # Output: "s'teL ekat edoCteeL tsetnoc"
