def processString(s):
    processed = []

    for c in s:
        if c != '#':
            processed.append(c)
        elif processed:
            processed.pop()

    return ''.join(processed)

def backspaceCompare(s, t):
    return processString(s) == processString(t)
s = "ab#c"
t = "ad#c"
print(backspaceCompare(s, t))  # Output: True
