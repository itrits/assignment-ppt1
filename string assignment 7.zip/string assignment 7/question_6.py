def rotateString(s, goal):
    if len(s) != len(goal):
        return False

    s_shifted = s + s
    return goal in s_shifted
s = "abcde"
goal = "cdeab"
print(rotateString(s, goal))  # Output: True
